﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace MyBanking.Plugins
{
    public class ValidateWithdrawalPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService orgService = serviceFactory.CreateOrganizationService(context.UserId);

            if (context.Depth > 1) return;

            if (context.InputParameters == null ||
                !context.InputParameters.Contains("Target") ||
                !(context.InputParameters["Target"] is Entity))
            {
                return;
            }

            Entity transaction = (Entity)context.InputParameters["Target"];

            if (transaction.LogicalName != "new_transaction") return;

            OptionSetValue transactionType = transaction.GetAttributeValue<OptionSetValue>("new_transactiontype");
            if (transactionType == null || transactionType.Value != 100000001) return;

            try
            {
                Money amount = transaction.GetAttributeValue<Money>("new_amount");
                EntityReference accountRef = transaction.GetAttributeValue<EntityReference>("new_bankaccount");

                if (amount == null || accountRef == null)
                {
                    throw new InvalidPluginExecutionException("يجب تحديد الحساب البنكي ومبلغ العملية.");
                }

                if (amount.Value <= 0)
                {
                    throw new InvalidPluginExecutionException("مبلغ السحب يجب أن يكون أكبر من الصفر.");
                }

                Entity account = orgService.Retrieve(
                    accountRef.LogicalName,
                    accountRef.Id,
                    new ColumnSet("cr05f_balance")
                );

                if (account == null)
                {
                    throw new InvalidPluginExecutionException("الحساب البنكي المحدد غير موجود.");
                }

                decimal currentBalance = account.GetAttributeValue<decimal?>("cr05f_balance") ?? 0m;

                if (amount.Value > currentBalance)
                {
                    throw new InvalidPluginExecutionException("الرصيد الحالي لا يكفي لإتمام عملية السحب.");
                }

                decimal updatedBalance = currentBalance - amount.Value;

                Entity accountToUpdate = new Entity(accountRef.LogicalName, account.Id);
                accountToUpdate["cr05f_balance"] = updatedBalance;

                orgService.Update(accountToUpdate);
            }
            catch (InvalidPluginExecutionException)
            {
                throw;
            }
            catch (Exception ex)
            {
                tracing?.Trace("ValidateWithdrawalPlugin Error: {0}", ex.ToString());
                throw new InvalidPluginExecutionException("حدث خطأ أثناء تنفيذ عملية السحب.", ex);
            }
        }
    }
}