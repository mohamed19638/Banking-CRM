﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace MyBanking.Plugins
{
    public class TransferPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(
                    typeof(IPluginExecutionContext));

            ITracingService tracing =
                (ITracingService)serviceProvider.GetService(
                    typeof(ITracingService));

            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(
                    typeof(IOrganizationServiceFactory));

            IOrganizationService orgService =
                serviceFactory.CreateOrganizationService(context.UserId);

            if (context.Depth > 1)
                return;

            if (context.InputParameters == null ||
                !context.InputParameters.Contains("Target") ||
                !(context.InputParameters["Target"] is Entity))
            {
                return;
            }

            Entity transaction =
                (Entity)context.InputParameters["Target"];

            if (transaction.LogicalName != "new_transaction")
                return;

            OptionSetValue transactionType =
                transaction.GetAttributeValue<OptionSetValue>(
                    "new_transactiontype");

            // Transfer
            if (transactionType == null ||
                transactionType.Value != 100000002)
            {
                return;
            }

            try
            {
                Money amount =
                    transaction.GetAttributeValue<Money>("new_amount");

                EntityReference fromAccountRef =
                    transaction.GetAttributeValue<EntityReference>(
                        "new_bankaccount");

                EntityReference toAccountRef =
                   transaction.GetAttributeValue<EntityReference>(
                       "cr05f_destinationaccount");

                if (amount == null ||
                    fromAccountRef == null ||
                    toAccountRef == null)
                {
                    throw new InvalidPluginExecutionException(
                        "يجب تحديد الحساب المصدر والحساب المستلم ومبلغ التحويل.");
                }

                if (amount.Value <= 0)
                {
                    throw new InvalidPluginExecutionException(
                        "مبلغ التحويل يجب أن يكون أكبر من الصفر.");
                }

                if (fromAccountRef.Id == toAccountRef.Id)
                {
                    throw new InvalidPluginExecutionException(
                        "لا يمكن التحويل إلى نفس الحساب.");
                }

                // Get source account
                Entity fromAccount = orgService.Retrieve(
                    fromAccountRef.LogicalName,
                    fromAccountRef.Id,
                    new ColumnSet("cr05f_balance"));

                // Get destination account
                Entity toAccount = orgService.Retrieve(
                    toAccountRef.LogicalName,
                    toAccountRef.Id,
                    new ColumnSet("cr05f_balance"));

                if (fromAccount == null || toAccount == null)
                {
                    throw new InvalidPluginExecutionException(
                        "أحد الحسابات البنكية غير موجود.");
                }

                decimal fromBalance =
                    fromAccount.GetAttributeValue<decimal?>(
                        "cr05f_balance") ?? 0m;

                decimal toBalance =
                    toAccount.GetAttributeValue<decimal?>(
                        "cr05f_balance") ?? 0m;

                // Check source balance
                if (amount.Value > fromBalance)
                {
                    throw new InvalidPluginExecutionException(
                        "الرصيد الحالي للحساب المصدر لا يكفي لإتمام عملية التحويل.");
                }

                // Calculate new balances
                decimal newFromBalance =
                    fromBalance - amount.Value;

                decimal newToBalance =
                    toBalance + amount.Value;

                // Update source account
                Entity fromAccountUpdate =
                    new Entity(
                        fromAccountRef.LogicalName,
                        fromAccountRef.Id);

                fromAccountUpdate["cr05f_balance"] =
                    newFromBalance;

                orgService.Update(fromAccountUpdate);

                // Update destination account
                Entity toAccountUpdate =
                    new Entity(
                        toAccountRef.LogicalName,
                        toAccountRef.Id);

                toAccountUpdate["cr05f_balance"] =
                    newToBalance;

                orgService.Update(toAccountUpdate);
            }
            catch (InvalidPluginExecutionException)
            {
                throw;
            }
            catch (Exception ex)
            {
                tracing?.Trace(
                    "TransferPlugin Error: {0}",
                    ex.ToString());

                throw new InvalidPluginExecutionException(
                    "حدث خطأ أثناء تنفيذ عملية التحويل.",
                    ex);
            }
        }
    }
}